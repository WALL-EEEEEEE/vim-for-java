package kg.ash.javavi.output;

import org.junit.Ignore;
import org.junit.Test;

public class OutputSimilarAnnotationsTest {

    @Ignore
    @Test
    public void testCorrect() {
    }
    
}
