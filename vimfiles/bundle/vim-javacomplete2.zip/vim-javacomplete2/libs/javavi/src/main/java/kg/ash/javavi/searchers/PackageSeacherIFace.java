package kg.ash.javavi.searchers;

import java.util.List;

public interface PackageSeacherIFace {

    public List<PackageEntry> loadEntries();
    
}
