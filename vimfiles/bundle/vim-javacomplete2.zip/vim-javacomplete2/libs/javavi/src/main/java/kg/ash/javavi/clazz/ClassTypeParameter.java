package kg.ash.javavi.clazz;

public class ClassTypeParameter {

    private String name;

    public ClassTypeParameter(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
