package kg.ash.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.math.BigDecimal;

public class LambdaAnonClass {

    public LambdaAnonClass() {
        List<? super Integer[]> lint = new ArrayList<>();

        lint.stream().filter(t -> {
            Integer i = new Integer();
            t.;
        });

        lint.stream().filter((t, d) -> {
            Integer i = new Integer();
            d.
        });
    }
    
}
