package kg.ash.javavi;

import java.util.function.Predicate;

public class LambdaReturnClass {

    public Predicate<Integer> getCondition() {
        return p -> p.
    }
    
}
